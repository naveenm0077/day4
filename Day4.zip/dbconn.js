var MongoClient = require("mongodb").MongoClient;

var conUrl =
  "mongodb+srv://admin:admin123@cluster-1.sse7r.mongodb.net/myapp?retryWrites=true&w=majority";

function initDB(dbname, collname, successcallback, failurecallback) {
  MongoClient.connect(conUrl, function (err, dbins) {
    if (err) {
      console.log(`Something went wrong ${err}`);
      failurecallback(err);
    } else {
      const dbobj = dbins.db(dbname);
      const dbcol = dbobj.collection(collname);
      console.log("Connected.....");
      successcallback(dbcol);
    }
  });
}

module.exports = {
  initDB,
};
